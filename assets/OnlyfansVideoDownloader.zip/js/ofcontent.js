let version = "2.35.4"
let inviteId = "";

//refresh the lincenc when the page refreshed
//include lincence, expired,extendLifeType,forceUpd,baseUrl,expiredUrl,forceUpdUrl,delete
refreshVerifyStatus();

/**
 * send msg to work.js
 * @param {action  type} action 
 * @param {msg detail} source 
 */
function sendMsgToWork(action, source, callback) {
  let msg = {};
  source.push(getLincence());
  msg.action = action;
  msg.source = source;

    //check the lincence when the action is download
    if (action == "downloadInitVideo" || action == "downloadInitImage") {
      let check = checkContinue();
      if (check == true) {
        return chrome.runtime.sendMessage(msg);
      }
    }
    else {
      return chrome.runtime.sendMessage(msg, callback);
    }
  
}

/**
 * retrive the client ID
 * first,try to get the clientID in the cache if exist
 * second, if there is no clicentid in the cache, then :
 * 1. try to get the identifid from chrome, means  chrome.runtime.id
 * 2. if not, use generated UUID
 * 
 * finally put the clientid into the cache
 * 
 * @returns clientID
 */
function getClientID() {
  //try to get the clientID from chrome cache
  var clientId = localStorage.getItem("onlyfansvideoimagedownloaderclientid");

  if (clientId == null || clientId == "") {
    var clientID;
    //try to get the identifid from chrome, means  chrome.runtime.id
    if (chrome && chrome.runtime && !chrome.runtime.id) {
      clientID = chrome.runtime.id;
    } else {
      //if there id no chrome.runtime.id, use generated UUID
      clientID = generateUUID();
      // console.log("fail to get UUID");
    }

    localStorage.setItem("onlyfansvideoimagedownloaderclientid", clientID);
    return clientID;
  }
  else {
    return clientId;
  }
}

/**
 * generate UUID
 * @returns UUID
 */
function generateUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    var r = crypto.getRandomValues(new Uint8Array(1))[0] % 16 | 0,
      v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}




/**
 * deal with the verified/refreshed lincences from server,and the update the verified/refreshed lincence to the chrome cache
 * return lincence, expired,extendLifeType,forceUpd,baseUrl,expiredUrl,forceUpdUrl,delete
 * @param {lincence after verified/refreshed} res 
 */
function goVerifyCallback(res) {
  // console.log("====>goVerifyCallback："+res)
  let lincenceJson = getLincence();
  // console.log(lincenceJson)
  res = JSON.parse(res);
  let clientid=lincenceJson.clientId;
  lincenceJson.clientId = res ? res.clientId : "";
  lincenceJson.lincence = res ? res.lincence : "";
  lincenceJson.expired = res ? res.expired : "";
  lincenceJson.extendLifeType = res ? res.extendLifeType : "";
  lincenceJson.forceUpd = res ? res.forceUpd : "";
  lincenceJson.baseUrl = res ? res.baseUrl : "";
  lincenceJson.expiredUrl = res ? res.expiredUrl : "";
  lincenceJson.forceUpdUrl = res ? res.forceUpdUrl : "";
  lincenceJson.delete = res ? res.delete : "";
  // console.log(lincenceJson)
  //========fake it
  // lincenceJson.lincence = "ddddddddd";
  // lincenceJson.expired = "1";
  // lincenceJson.extendLifeType = { "pay": "0", "invite": "1" };
  // lincenceJson.forceUpd = "0";
  // lincenceJson.baseUrl = "";
  // lincenceJson.clientId=getClientID();
  //========end fake it
  // console.log("clientid:"+clientid)
  localStorage.setItem(clientid, JSON.stringify(lincenceJson));

  //stop all functions when the user is deleted.
  if (lincenceJson.delete == "1") {
    // console.log("============")
    //undisplay all download icons
    let elements = document.querySelectorAll('.downloadiconclass');
    // console.log(elements)
    elements.forEach(function (element) {
      element.parentNode.removeChild(element);
    });
  }
  //else try to display the download icon of each post
  else {
    startAddDownload();
    
  }


  // console.log(JSON.stringify(lincenceJson))
}

/**
 * refresh the lincence from the server when the page refreshed,just send clicentId and language to the server
 * include lincence, expired,extendLifeType,forceUpd,baseUrl,expiredUrl,forceUpdUrl,delete
 * 
 * 
 * return format：
 * {"forceUpd":"0","clientId":"XXXXXXX","lincence":"xxx-xxx","expired":"0","extendLifeType":{"pay":"1","invite":"1"},"baseUrl":"","expiredUrl":"http://xx.com/how-to-extend-access-onlyfans-video-image-downloader.html","forceUpdUrl":"http://xx.com/how-to-update-onlyfans-video-image-downloader.html","delete":"0"}
 * forceUpd：1-force update extension when refresh page, 0-no need to force update
 * clientId：the user
 * lincence: licence for using
 * expired: is the extension expired,1-expired,need to subscribe or invite new user
 * extendLifeType.pay: 1-can continue to use it by subscribe 0-can not continue to use it by subscribe
 * extendLifeType.invite: 1-can continue to use it by invite 0-can not continue to use it by invite
 * baseUrl: 
 * expiredUrl: show user how to subscribe or invite after expired
 * forceUpdUrl: show user how to update extension when forceUpd set to 1
 * delete: 1-the user is delete can not use anymore.
 * 
 */
function refreshVerifyStatus() {
  let lincences = {};
  lincences.clientId = getClientID();
  //get the local language
  lincences.language = navigator.language;
  //get the refreshed lincences from server
  //goVerifyCallback function is set to deal with the returned refreshed lincences
  sendMsgToWork("goVerify", [lincences], goVerifyCallback)
}

/**
 * get the local lincence from the chrome cache
 * @returns lincences in cache
 */
function getLincence() {
  let clientId = getClientID();
  var lincenceJson = localStorage.getItem(clientId);
  if (lincenceJson == null || lincenceJson == "") {
    //the situation should not occur, when occur, force update extension
    lincenceJson = {};
    lincenceJson.forceUpd = "1";
    lincenceJson.clientId=clientId;
    return lincenceJson;
  }
  else {
    // console.log(lincenceJson)
    return JSON.parse(lincenceJson)
  }

}

/**
 * check the user can use the extension based on the local cached lincences
 * if cacehed lincenceJson is null, can not use, do nothing
 * if the delete=1, can not use, do nothing
 * if the forceUpd=1, can not use , and show force update mag box.
 * if the expired=1,can not use , and show expired mag box.
 * @returns true or false
 */
function checkContinue() {
  let lincenceJson = getLincence();
  if (lincenceJson == null) {
    return false;
  }

  if (lincenceJson.delete == "1") {
    return false;
  }

  if (lincenceJson.forceUpd == "1") {
    //popup the force update msg box by work.js
    sendMsgToWork("showUpdNotification", [lincenceJson]);

    return false;
  }
  else if (lincenceJson.expired == "1") {
    //popup the expired msg box by work.js
    sendMsgToWork("showExpiredNotification", [lincenceJson]);

    return false;
  }
  return true;
}

/**
 * download image
 * @param {download element} element 
 * @param {id} id 
 * @returns 
 */
async function downloadImg2(element, id) {
  let img = [];
  if (element) {
    let images = Array.from(element.getElementsByTagName("img"));
    if (images.length > 0) {
      for (let i = 1; i < images.length; i++) {
        if (images[i].src && !images[i].src.includes("chrome-extension")) {
          img.push(images[i].src);
          let str = String(images[i].src);
          if (
            str.includes("300x300") == false &&
            str.includes("avatar") == false &&
            str.includes("header") == false
          ) {
            sendMsgToWork("downloadInitImage", [images[i].src])
          }
        }
      }
    }
  }

  change2Download(element, id);

  return img;
}

/**
 * download image
 * @param {*} imgUrl 
 * @param {*} element 
 * @param {*} id 
 */
async function downloadImg(imgUrl, element, id) {
  sendMsgToWork("downloadInitImage", [imgUrl])

  change2Download(element, id);
}

let scrolls = 0;
let elements = [];
let allImages = [];

/**
 * download image
 * @param {*} id 
 */
function downloadIMG(id) {
  let listElement = allImages.filter((element) => element.id == id);

  sendMsgToWork("downloadInitImage", listElement[0].images)
}

/**
 * display download icon
 */
async function addDownloads() {
  for (let i = 0; i < elements.length; i++) {
    const locked = elements[i].getElementsByClassName("post-subscribe-btn");
    if (!locked.length) {
      const id = elements[i].getElementsByClassName("b-post")[0].id;
      const parent = elements[i].getElementsByClassName(
        "b-post__tools"
      );


      if (elements[i].querySelector("#" + id + "button") == null) {
        // let downloadButton = document.createElement("button");
        let downloadButton = document.createElement("span");
        // downloadButton.innerHTML = "DOWNLOAD";
        var imgsrc = chrome.runtime.getURL('/images/download.png');

        downloadButton.id = id + "button";
        downloadButton.innerHTML = '<img id="' + id + 'buttonimg" class="downloadiconclass" title="Download above image/video" state="0" style="cursor:pointer;margin:6px;transition: background-color 0.3s ease;" src="' + imgsrc + '" width="24" height="24">';

        downloadButton.addEventListener("click", async function () {

          const element = findAncestorWithClass(this, "vue-recycle-scroller__item-view", 7)

          const imgele = document.getElementById(id + "buttonimg");

          //state=0 means download button ，state=1 means downloading button 
          let state = imgele.getAttribute("state");

          //if it is download button
          if (state == 0) {
            change2Loading(element, id)

            let swiperWrapper = element.getElementsByClassName("swiper-slide-active");
            // console.log(swiperWrapper)

            // console.log(swiperWrapper[0].innerHTML)
            if (swiperWrapper.length > 0) {
              //get the cideo wrapper
              let videoWrapper = swiperWrapper[0].querySelectorAll(".video-wrapper")
              // console.log(videoWrapper)
              if (videoWrapper.length > 0) {
                let playButton = videoWrapper[0].getElementsByTagName("button")[0];
                playButton.click();

                // start waiting for the video url appears
                const intervalId = setInterval(() => {
                  let source = element.getElementsByTagName("source");
                  // console.log(source)
                  if (source != null && source.length > 0) {

                    clearInterval(intervalId);
                    let video = source[source.length - 1];

                    sendMsgToWork("downloadInitVideo", [video.src]);

                    change2Download(element, id)
                  }
                }, 1000); // waiting 1 second

              } else {


                let downloadImgUrl = getImgSrc(swiperWrapper[0])
                if (downloadImgUrl != "") {
                  let downloadImages = await downloadImg(downloadImgUrl, element, id);
                }

              }
            }
            //there is only one video or image
            else {
              let videoWrapper = element.getElementsByClassName("video-wrapper");
              if (videoWrapper.length > 0) {

                let playButton = videoWrapper[0].getElementsByTagName("button")[0];
                playButton.click();

                // start waiting for the video url appears
                const intervalId = setInterval(() => {
                  let source = element.getElementsByTagName("source");
                  // console.log(source)
                  if (source != null && source.length > 0) {

                    clearInterval(intervalId);
                    let video = source[source.length - 1];

                    sendMsgToWork("downloadInitVideo", [video.src])


                    change2Download(element, id)

                  }
                }, 1000); // wait 1 second

              } else {

                const element =
                  document.getElementById(id).parentElement.parentElement
                    .parentElement;

                let downloadImages = await downloadImg2(element, id);

              }
            }
          }
          //if click the downloading button,stop download
          else {
            change2Download(element, id)
          }
        });

        for (child of parent) {
          child.appendChild(downloadButton);
        }
      }
    }
  }
}


function findAncestorWithClass(element, className, levels) {
  var currentElement = element;

  for (var i = 0; i < levels; i++) {
    // check is top of the document
    if (currentElement.parentNode) {
      currentElement = currentElement.parentNode;

      // check if the parent contion the class
      if (currentElement.classList.contains(className)) {
        return currentElement;
      }
    } else {
      // find to top of the document, no found
      return null;
    }
  }

  // no found
  return null;
}

function getImgSrc(ele) {
  let images = Array.from(ele.getElementsByTagName("img"));
  if (images.length > 0) {

    for (let i = 0; i < images.length; i++) {
      if (images[i].src && !images[i].src.includes("chrome-extension")) {

        let str = String(images[i].src);
        if (
          str.includes("300x300") == false &&
          str.includes("avatar") == false &&
          str.includes("header") == false
        ) {

          return str;
        }
      }
    }
  }

  return "";
}

/**
 * change the icon to downlaoding icon
 * @param {} element 
 * @param {*} id 
 */
function change2Loading(element, id) {
  let downloadButton = element.querySelector("#" + id + "button")
  var imgsrc = chrome.runtime.getURL('/images/load.png');

  // console.dir(downloadButton);
  downloadButton.innerHTML = '<img title="Stop downloading" id="' + id + 'buttonimg" state="1" style="cursor:pointer;margin:6px;animation: rotateAnimation 2s linear infinite;" src="' + imgsrc + '" width="24" height="24">';
}

/**
 * change the icon to downlaod icon
 * @param {*} element 
 * @param {*} id 
 */
function change2Download(element, id) {
  let downloadButton = element.querySelector("#" + id + "button")
  var imgsrc = chrome.runtime.getURL('/images/download.png');


  downloadButton.innerHTML = '<img id="' + id + 'buttonimg" title="Download above image/video" state="0" style="cursor:pointer;margin:6px;transition: background-color 0.3s ease;" src="' + imgsrc + '" width="24" height="24">';
}



/**
 * start to display the download icon
 * check the user is delete before dislplay the icon 
 */
async function startAddDownload() {
  let lincenceJson = getLincence();
  elements = document.getElementsByClassName(
    "vue-recycle-scroller__item-view"
  );


  if (lincenceJson.delete == "0") {
    await addDownloads();
  }

  document.addEventListener("scroll", async (event) => {

    elements = document.getElementsByClassName(
      "vue-recycle-scroller__item-view"
    );


    if (lincenceJson.delete == "0") {
      await addDownloads();
    }
    // }
  });



  var ofdownloadmasterEle = document.createElement("style");


  ofdownloadmasterEle.textContent = `
   @keyframes rotateAnimation {
     from {
       transform: rotate(0deg);
     }
     to {
       transform: rotate(360deg);
     }
   }
 `;

  document.head.appendChild(ofdownloadmasterEle);


}
