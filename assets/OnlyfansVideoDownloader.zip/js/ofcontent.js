//refresh the lincenc when the page refreshed
//if someone is delete,hidden the download icon
refreshVerifyStatus();

//set the clientId to the buy me a coffee page, and hidden it.
autoSetClientId();


/**
 * send msg to work.js
 * @param {action  type} action 
 * @param {msg detail} source 
 */
function sendMsgToWork(action, source, callback) {
  let msg = {};
  source.push(getLincence());
  msg.action = action;
  msg.source = source;

  //check the lincence when the action is download
  if (action == "downloadInitVideo" || action == "downloadInitImage") {
    let check = checkContinue();
    if (check == true) {
      return chrome.runtime.sendMessage(msg);
    }
  }
  else {
    return chrome.runtime.sendMessage(msg, callback);
  }

}






/**
 * deal with the verified/refreshed lincences from server,and the update the verified/refreshed lincence to the chrome cache
 * return lincence, expired,extendLifeType,forceUpd,baseUrl,expiredUrl,forceUpdUrl,delete
 * @param {lincence after verified/refreshed} res 
 */
function goVerifyCallback(res) {
  //stop all functions when the user is deleted.

    var verifyJson = "";
    try {
      verifyJson = JSON.parse(res);
    }
    catch
    {
      verifyJson = "";
    }


    if(verifyJson != null && verifyJson != "" && verifyJson.hasOwnProperty("delete") && verifyJson.delete == 0)
    {
      startAddDownload();
    }
    else
    {
      //undisplay all download icons
      let elements = document.querySelectorAll('.downloadiconclass');
      // console.log(elements)
      elements.forEach(function (element) {
        element.parentNode.removeChild(element);
      });
    }
  // console.log(JSON.stringify(lincenceJson))
}

/**
 * refresh the lincence from the server when the page refreshed,just send clicentId and language to the server
 * include lincence, expired,extendLifeType,forceUpd,baseUrl,expiredUrl,forceUpdUrl,delete
 * 
 * 
 * return format：
 * {"forceUpd":"0","clientId":"XXXXXXX","lincence":"xxx-xxx","expired":"0","extendLifeType":{"pay":"1","invite":"1"},"baseUrl":"","expiredUrl":"http://xx.com/how-to-extend-access-onlyfans-video-image-downloader.html","forceUpdUrl":"http://xx.com/how-to-update-onlyfans-video-image-downloader.html","delete":"0"}
 * forceUpd：1-force update extension when refresh page, 0-no need to force update
 * clientId：the user
 * lincence: licence for using
 * expired: is the extension expired,1-expired,need to subscribe or invite new user
 * extendLifeType.pay: 1-can continue to use it by subscribe 0-can not continue to use it by subscribe
 * extendLifeType.invite: 1-can continue to use it by invite 0-can not continue to use it by invite
 * baseUrl: 
 * expiredUrl: show user how to subscribe or invite after expired
 * forceUpdUrl: show user how to update extension when forceUpd set to 1
 * delete: 1-the user is delete can not use anymore.
 * 
 */
function refreshVerifyStatus() {
  // let lincences = {};

  // lincences.clientId = getClientID();
  // //get the local language
  // lincences.language = navigator.language;
  //get the refreshed lincences from server
  //goVerifyCallback function is set to deal with the returned refreshed lincences
  // sendMsgToWork("goVerify", [lincences], goVerifyCallback)

  //   chrome.runtime.sendMessage({ action: "goVerify" }, function(response) {
  //     console.log("Response from backend1:", response);
  // });

  chrome.runtime.sendMessage({ action: "goVerify" }, goVerifyCallback);

}

/**
 * get the local lincence from the chrome cache
 * @returns lincences in cache
 */
function getLincence() {
  // let clientId = getClientID();
  // var lincenceJson = localStorage.getItem(clientId);
  // if (lincenceJson == null || lincenceJson == "") {
  //   //the situation should not occur, when occur, force update extension
  //   lincenceJson = {};
  //   lincenceJson.forceUpd = "1";
  //   lincenceJson.clientId=clientId;
  //   return lincenceJson;
  // }
  // else {
  //   // console.log(lincenceJson)
  //   return JSON.parse(lincenceJson)
  // }

}

/**
 * check the user can use the extension based on the local cached lincences
 * if cacehed lincenceJson is null, can not use, do nothing
 * if the delete=1, can not use, do nothing
 * if the forceUpd=1, can not use , and show force update mag box.
 * if the expired=1,can not use , and show expired mag box.
 * @returns true or false
 */
function checkContinue() {
  // let lincenceJson = getLincence();
  // if (lincenceJson == null) {
  //   return false;
  // }

  // if (lincenceJson.delete == "1") {
  //   return false;
  // }

  // if (lincenceJson.forceUpd == "1") {
  //   //popup the force update msg box by work.js
  //   sendMsgToWork("showUpdNotification", [lincenceJson]);

  //   return false;
  // }
  // else if (lincenceJson.expired == "1") {
  //   //popup the expired msg box by work.js
  //   sendMsgToWork("showExpiredNotification", [lincenceJson]);

  //   return false;
  // }
  //remove the old check,
  //new check in work.js, check in every request to num
  return true;
}

/**
 * download image
 * @param {download element} element 
 * @param {id} id 
 * @returns 
 */
async function downloadImg2(element, id) {
  let img = [];
  if (element) {
    let images = Array.from(element.getElementsByTagName("img"));
    if (images.length > 0) {
      for (let i = 1; i < images.length; i++) {
        if (images[i].src && !images[i].src.includes("chrome-extension")) {
          img.push(images[i].src);
          let str = String(images[i].src);
          if (
            str.includes("300x300") == false &&
            str.includes("avatar") == false &&
            str.includes("header") == false
          ) {
            sendMsgToWork("downloadInitImage", [images[i].src])
          }
        }
      }
    }
  }

  change2Download(element, id);

  return img;
}

/**
 * download image
 * @param {*} imgUrl 
 * @param {*} element 
 * @param {*} id 
 */
async function downloadImg(imgUrl, element, id) {
  sendMsgToWork("downloadInitImage", [imgUrl])

  change2Download(element, id);
}

let scrolls = 0;
let elements = [];
let allImages = [];

/**
 * download image
 * @param {*} id 
 */
function downloadIMG(id) {
  let listElement = allImages.filter((element) => element.id == id);

  sendMsgToWork("downloadInitImage", listElement[0].images)
}

/**
 * display download icon
 */
async function addDownloads() {
  for (let i = 0; i < elements.length; i++) {
    const locked = elements[i].getElementsByClassName("post-subscribe-btn");
    if (!locked.length) {
      const id = elements[i].getElementsByClassName("b-post")[0].id;
      const parent = elements[i].getElementsByClassName(
        "b-post__tools"
      );


      if (elements[i].querySelector("#" + id + "button") == null) {
        // let downloadButton = document.createElement("button");
        let downloadButton = document.createElement("span");
        // downloadButton.innerHTML = "DOWNLOAD";
        var imgsrc = chrome.runtime.getURL('/images/download.png');

        downloadButton.id = id + "button";
        downloadButton.innerHTML = '<img id="' + id + 'buttonimg" class="downloadiconclass" title="Download above image/video" state="0" style="cursor:pointer;margin:6px;transition: background-color 0.3s ease;" src="' + imgsrc + '" width="24" height="24">';

        downloadButton.addEventListener("click", async function () {

          const element = findAncestorWithClass(this, "vue-recycle-scroller__item-view", 7)

          const imgele = document.getElementById(id + "buttonimg");

          //state=0 means download button ，state=1 means downloading button 
          let state = imgele.getAttribute("state");

          //if it is download button
          if (state == 0) {
            change2Loading(element, id)

            let swiperWrapper = element.getElementsByClassName("swiper-slide-active");
            // console.log(swiperWrapper)

            // console.log(swiperWrapper[0].innerHTML)
            if (swiperWrapper.length > 0) {
              //get the cideo wrapper
              let videoWrapper = swiperWrapper[0].querySelectorAll(".video-wrapper")
              // console.log(videoWrapper)
              if (videoWrapper.length > 0) {
                let playButton = videoWrapper[0].getElementsByTagName("button")[0];
                playButton.click();

                // start waiting for the video url appears
                const intervalId = setInterval(() => {
                  let source = element.getElementsByTagName("source");
                  // console.log(source)
                  if (source != null && source.length > 0) {

                    clearInterval(intervalId);
                    let video = source[source.length - 1];

                    sendMsgToWork("downloadInitVideo", [video.src]);

                    change2Download(element, id)
                  }
                }, 1000); // waiting 1 second

              } else {


                let downloadImgUrl = getImgSrc(swiperWrapper[0])
                if (downloadImgUrl != "") {
                  let downloadImages = await downloadImg(downloadImgUrl, element, id);
                }

              }
            }
            //there is only one video or image
            else {
              let videoWrapper = element.getElementsByClassName("video-wrapper");
              if (videoWrapper.length > 0) {

                let playButton = videoWrapper[0].getElementsByTagName("button")[0];
                playButton.click();

                // start waiting for the video url appears
                const intervalId = setInterval(() => {
                  let source = element.getElementsByTagName("source");
                  // console.log(source)
                  if (source != null && source.length > 0) {

                    clearInterval(intervalId);
                    let video = source[source.length - 1];

                    sendMsgToWork("downloadInitVideo", [video.src])


                    change2Download(element, id)

                  }
                }, 1000); // wait 1 second

              } else {

                const element =
                  document.getElementById(id).parentElement.parentElement
                    .parentElement;

                let downloadImages = await downloadImg2(element, id);

              }
            }
          }
          //if click the downloading button,stop download
          else {
            change2Download(element, id)
          }
        });

        for (child of parent) {
          child.appendChild(downloadButton);
        }
      }
    }
  }
}


function findAncestorWithClass(element, className, levels) {
  var currentElement = element;

  for (var i = 0; i < levels; i++) {
    // check is top of the document
    if (currentElement.parentNode) {
      currentElement = currentElement.parentNode;

      // check if the parent contion the class
      if (currentElement.classList.contains(className)) {
        return currentElement;
      }
    } else {
      // find to top of the document, no found
      return null;
    }
  }

  // no found
  return null;
}

function getImgSrc(ele) {
  let images = Array.from(ele.getElementsByTagName("img"));
  if (images.length > 0) {

    for (let i = 0; i < images.length; i++) {
      if (images[i].src && !images[i].src.includes("chrome-extension")) {

        let str = String(images[i].src);
        if (
          str.includes("300x300") == false &&
          str.includes("avatar") == false &&
          str.includes("header") == false
        ) {

          return str;
        }
      }
    }
  }

  return "";
}

/**
 * change the icon to downlaoding icon
 * @param {} element 
 * @param {*} id 
 */
function change2Loading(element, id) {
  let downloadButton = element.querySelector("#" + id + "button")
  var imgsrc = chrome.runtime.getURL('/images/load.png');

  // console.dir(downloadButton);
  downloadButton.innerHTML = '<img title="Stop downloading" id="' + id + 'buttonimg" state="1" style="cursor:pointer;margin:6px;animation: rotateAnimation 2s linear infinite;" src="' + imgsrc + '" width="24" height="24">';
}

/**
 * change the icon to downlaod icon
 * @param {*} element 
 * @param {*} id 
 */
function change2Download(element, id) {
  let downloadButton = element.querySelector("#" + id + "button")
  var imgsrc = chrome.runtime.getURL('/images/download.png');


  downloadButton.innerHTML = '<img id="' + id + 'buttonimg" title="Download above image/video" state="0" style="cursor:pointer;margin:6px;transition: background-color 0.3s ease;" src="' + imgsrc + '" width="24" height="24">';
}



/**
 * start to display the download icon
 * check the user is delete before dislplay the icon 
 */
async function startAddDownload() {
  // let lincenceJson = getLincence();
  elements = document.getElementsByClassName(
    "vue-recycle-scroller__item-view"
  );


  // if (lincenceJson.delete == "0") {
  await addDownloads();
  // }

  document.addEventListener("scroll", async (event) => {

    elements = document.getElementsByClassName(
      "vue-recycle-scroller__item-view"
    );


    // if (lincenceJson.delete == "0") {
    await addDownloads();
    // }
    // }
  });



  var ofdownloadmasterEle = document.createElement("style");


  ofdownloadmasterEle.textContent = `
   @keyframes rotateAnimation {
     from {
       transform: rotate(0deg);
     }
     to {
       transform: rotate(360deg);
     }
   }
 `;

  document.head.appendChild(ofdownloadmasterEle);


}


// window.onerror = function (message, source, lineno, colno, error) {
//   console.error('global error:', message, source, lineno, colno, error);
// };



//set clientId to buy me a coffee message box and hide the box
//only work on bymeacoffee.com
function autoSetClientId()
{
  const domain = document.location.hostname;
  if(domain.indexOf("buymeacoffee.com")>-1)
  {
    let spanElement = null;

    //get all span of page
    const spanElements = document.querySelectorAll('span');
    
    //for each every span
    spanElements.forEach(span => {
      //find the Join span. check if the span text is Join , it is a button ,button text is Join.
      if (span.textContent.includes("Join")) {
        spanElement = span;
      }
    });
    
    
    //add click hanlder to the Join span
    //once click the Join span, fill the clientId into the messsge box and hidden it.
    spanElement.addEventListener('click', function () {
      //search message box(textarea) ,fill the clientId into the msg box and hidden it, in case user change the id
      setClientIdToBuymeaCoffee();
    });
  }  
}

//search message box(textarea) ,fill the clientId into the msg box and hidden it, in case user change the id
function setClientIdToBuymeaCoffee() {
  getClientID().then((clientId) => {

    //search the message box, the box's placeholder is "Say something nice", it can be seen on the page.
    const textareaElement = document.querySelector('textarea[placeholder="Say something nice"]');

    //get emo box element beside the message box
    const emoElement = document.querySelector('div.emoji-picker-toggle-container');

    if (textareaElement) {
      //set the clientId into the message box
      textareaElement.value = clientId;
      //hidden the message box
      textareaElement.style.display = 'none';
      //hidden the emo box
      emoElement.style.display = 'none';
    } 
  })
}

async function getClientID() {
  //try to get the clientID from chrome cache

  var clientIdObj = await chrome.storage.local.get('onlyfansvideoimagedownloaderclientid');
  // console.log(clientIdObj)

  if (clientIdObj != null && clientIdObj != "") {
    return clientIdObj.onlyfansvideoimagedownloaderclientid;
  }
  return "-";

}
